const db = require("../config/db");
const Patient = {
  create: (data, cb) => db.query("INSERT INTO patients SET ?", data, cb),
  getAll: cb => db.query("SELECT * FROM patients", cb),
  getById: (id, cb) => db.query("SELECT * FROM patients WHERE id=?", [id], cb),
  update: (id, data, cb) => db.query("UPDATE patients SET ? WHERE id=?", [data, id], cb),
  delete: (id, cb) => db.query("DELETE FROM patients WHERE id=?", [id], cb)
};
module.exports = Patient;