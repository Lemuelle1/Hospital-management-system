const db = require("../config/db");
const Appointment = {
  create: (data, cb) => db.query("INSERT INTO appointments SET ?", data, cb),
  getAll: cb => db.query("SELECT * FROM appointments", cb),
  getById: (id, cb) => db.query("SELECT * FROM appointments WHERE id=?", [id], cb),
  update: (id, data, cb) => db.query("UPDATE appointments SET ? WHERE id=?", [data, id], cb),
  delete: (id, cb) => db.query("DELETE FROM appointments WHERE id=?", [id], cb)
};
module.exports = Appointment;