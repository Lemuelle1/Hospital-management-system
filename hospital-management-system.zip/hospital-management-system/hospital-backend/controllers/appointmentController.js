const Appointment = require("../models/Appointment");

exports.getAllAppointments = (req,res)=> Appointment.getAll((err,results)=>err?res.status(500).json(err):res.json(results));
exports.getAppointmentById = (req,res)=> Appointment.getById(req.params.id,(err,results)=>err?res.status(500).json(err):res.json(results[0]));
exports.createAppointment = (req,res)=> Appointment.create(req.body,(err,results)=>err?res.status(500).json(err):res.json({message:"Appointment created",id:results.insertId}));
exports.updateAppointment = (req,res)=> Appointment.update(req.params.id,req.body,(err)=>err?res.status(500).json(err):res.json({message:"Appointment updated"}));
exports.deleteAppointment = (req,res)=> Appointment.delete(req.params.id,(err)=>err?res.status(500).json(err):res.json({message:"Appointment deleted"}));