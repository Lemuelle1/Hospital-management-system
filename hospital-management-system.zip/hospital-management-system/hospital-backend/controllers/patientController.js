const Patient = require("../models/Patient");

exports.getAllPatients = (req,res)=> Patient.getAll((err,results)=>err?res.status(500).json(err):res.json(results));
exports.getPatientById = (req,res)=> Patient.getById(req.params.id,(err,results)=>err?res.status(500).json(err):res.json(results[0]));
exports.createPatient = (req,res)=> Patient.create(req.body,(err,results)=>err?res.status(500).json(err):res.json({message:"Patient created",id:results.insertId}));
exports.updatePatient = (req,res)=> Patient.update(req.params.id,req.body,(err)=>err?res.status(500).json(err):res.json({message:"Patient updated"}));
exports.deletePatient = (req,res)=> Patient.delete(req.params.id,(err)=>err?res.status(500).json(err):res.json({message:"Patient deleted"}));