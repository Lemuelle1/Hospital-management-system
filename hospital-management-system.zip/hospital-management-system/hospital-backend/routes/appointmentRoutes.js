const router = require("express").Router();
const ac = require("../controllers/appointmentController");
const auth = require("../middleware/authMiddleware");

router.get("/", auth, ac.getAllAppointments);
router.get("/:id", auth, ac.getAppointmentById);
router.post("/", auth, ac.createAppointment);
router.put("/:id", auth, ac.updateAppointment);
router.delete("/:id", auth, ac.deleteAppointment);

module.exports = router;