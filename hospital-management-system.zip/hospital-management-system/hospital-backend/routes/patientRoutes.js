const router = require("express").Router();
const pc = require("../controllers/patientController");
const auth = require("../middleware/authMiddleware");

router.get("/", auth, pc.getAllPatients);
router.get("/:id", auth, pc.getPatientById);
router.post("/", auth, pc.createPatient);
router.put("/:id", auth, pc.updatePatient);
router.delete("/:id", auth, pc.deletePatient);

module.exports = router;