const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const authRoutes = require('./routes/authRoutes');

dotenv.config();
const app = express();

// Middleware
app.use(cors()); // Allows your HTML files to talk to the server
app.use(express.json()); // Allows the server to read the data you send in 'fetch'

// Routes - This is where Member 3's work is linked
app.use('/api/auth', authRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log('Server running on http://localhost:${PORT}');
});